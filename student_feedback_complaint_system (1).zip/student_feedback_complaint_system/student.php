<?php
require_once 'functions.php'; require_role('student');
$u = current_user();
$stmt = db()->prepare("SELECT COUNT(*) total, SUM(status='Pending') pending, SUM(status='In Progress') progress, SUM(status='Resolved') resolved FROM complaints WHERE student_id=?");
$stmt->execute([$u['id']]); $stats = $stmt->fetch();
$stmt = db()->prepare("SELECT * FROM complaints WHERE student_id=? ORDER BY created_at DESC LIMIT 8");
$stmt->execute([$u['id']]); $complaints = $stmt->fetchAll();
page_start('Student Dashboard');
?>
<div class="page-heading"><div><span class="eyebrow">STUDENT PORTAL</span><h1>Hello, <?=e($u['name'])?> 👋</h1><p class="muted">Your feedback can help improve the campus.</p></div><div class="actions"><a class="btn" href="feedback.php">+ Give feedback</a><a class="btn secondary" href="complaint.php">+ Register complaint</a></div></div>
<div class="stats">
<div class="stat"><span>Total complaints</span><strong><?= (int)($stats['total'] ?? 0) ?></strong></div>
<div class="stat"><span>Pending</span><strong><?= (int)($stats['pending'] ?? 0) ?></strong></div>
<div class="stat"><span>In progress</span><strong><?= (int)($stats['progress'] ?? 0) ?></strong></div>
<div class="stat"><span>Resolved</span><strong><?= (int)($stats['resolved'] ?? 0) ?></strong></div>
</div>
<section class="panel"><div class="section-head"><h2>Recent complaints</h2><a href="my_complaints.php">View all</a></div>
<?php if (!$complaints): ?><p class="muted">You have not submitted any complaints yet.</p><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Complaint ID</th><th>Subject</th><th>Category</th><th>Date</th><th>Status</th></tr></thead><tbody>
<?php foreach ($complaints as $c): ?><tr><td>#<?=e($c['id'])?></td><td><?=e($c['subject'])?></td><td><?=e($c['category'])?></td><td><?=e(date('d M Y',strtotime($c['created_at'])))?></td><td><span class="status <?=strtolower(str_replace(' ','-',$c['status']))?>"><?=e($c['status'])?></span></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></section>
<?php page_end(); ?>
