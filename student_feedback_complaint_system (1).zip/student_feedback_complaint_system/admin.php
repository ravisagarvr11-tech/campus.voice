<?php
require_once 'functions.php'; require_role('admin');
$pdo = db();
$counts = $pdo->query("SELECT COUNT(*) total, SUM(status='Pending') pending, SUM(status='In Progress') progress, SUM(status='Resolved') resolved FROM complaints")->fetch();
$feedback_count = $pdo->query("SELECT COUNT(*) FROM feedback")->fetchColumn();
$complaints = $pdo->query("SELECT c.*,u.name,u.student_no,u.department FROM complaints c LEFT JOIN users u ON u.id=c.student_id ORDER BY c.created_at DESC")->fetchAll();
$feedback = $pdo->query("SELECT f.*,u.name,u.department FROM feedback f JOIN users u ON u.id=f.student_id ORDER BY f.created_at DESC LIMIT 20")->fetchAll();
page_start('Admin Dashboard');
?>
<div class="page-heading"><div><span class="eyebrow">ADMINISTRATION</span><h1>Admin dashboard</h1><p class="muted">Review student concerns and monitor campus feedback.</p></div></div>
<div class="stats">
<div class="stat"><span>Total complaints</span><strong><?= (int)($counts['total'] ?? 0) ?></strong></div>
<div class="stat"><span>Pending</span><strong><?= (int)($counts['pending'] ?? 0) ?></strong></div>
<div class="stat"><span>In progress</span><strong><?= (int)($counts['progress'] ?? 0) ?></strong></div>
<div class="stat"><span>Feedback entries</span><strong><?= (int)$feedback_count ?></strong></div>
</div>
<section class="panel"><div class="section-head"><h2>All complaints</h2><span class="muted"><?=count($complaints)?> records</span></div>
<?php if (!$complaints): ?><p class="muted">No complaints received.</p><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>ID / Date</th><th>Student</th><th>Complaint</th><th>Category</th><th>Priority</th><th>Status & response</th></tr></thead><tbody>
<?php foreach ($complaints as $c): ?><tr><td>#<?=e($c['id'])?><br><small><?=e(date('d M Y',strtotime($c['created_at'])))?></small></td><td><?php if ($c['is_anonymous']): ?><strong>Anonymous</strong><?php else: ?><?=e($c['name'])?><br><small><?=e($c['department'])?></small><?php endif; ?></td><td><strong><?=e($c['subject'])?></strong><br><small><?=e($c['description'])?></small></td><td><?=e($c['category'])?></td><td><?=e($c['priority'])?></td><td><form method="post" action="update_complaint.php" class="inline-form"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="id" value="<?=e($c['id'])?>"><select name="status"><option <?= $c['status']==='Pending'?'selected':'' ?>>Pending</option><option <?= $c['status']==='In Progress'?'selected':'' ?>>In Progress</option><option <?= $c['status']==='Resolved'?'selected':'' ?>>Resolved</option><option <?= $c['status']==='Rejected'?'selected':'' ?>>Rejected</option></select><textarea name="reply" rows="2" placeholder="Write response (optional)"></textarea><button class="btn small">Save</button></form></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></section>
<section class="panel"><div class="section-head"><h2>Recent student feedback</h2><span class="muted">Latest 20 entries</span></div>
<?php if (!$feedback): ?><p class="muted">No feedback submitted.</p><?php else: ?><div class="table-wrap"><table><thead><tr><th>Student</th><th>Topic</th><th>Faculty / Dept.</th><th>Rating</th><th>Comments</th></tr></thead><tbody>
<?php foreach ($feedback as $f): ?><tr><td><?=e($f['name'])?><br><small><?=e($f['department'])?></small></td><td><?=e($f['subject'])?></td><td><?=e($f['faculty'] ?: '—')?></td><td><?=str_repeat('★',(int)$f['rating'])?><?=str_repeat('☆',5-(int)$f['rating'])?></td><td><?=e($f['comments'])?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?></section>
<?php page_end(); ?>
