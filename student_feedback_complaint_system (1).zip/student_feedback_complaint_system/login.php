<?php
require_once 'functions.php';
if (!empty($_SESSION['user'])) redirect($_SESSION['user']['role'] === 'admin' ? 'admin.php' : 'student.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $stmt = db()->prepare("SELECT id,name,email,student_no,department,password,role FROM users WHERE email=?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user && password_verify($password, $user['password'])) {
        unset($user['password']);
        session_regenerate_id(true);
        $_SESSION['user'] = $user;
        redirect($user['role'] === 'admin' ? 'admin.php' : 'student.php');
    }
    $error = 'Incorrect email or password.';
}
page_start('Sign In');
?>
<div class="form-wrap"><h1>Welcome back</h1><p class="muted">Sign in to your CampusVoice account.</p>
<?php if ($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?>
<form method="post" class="panel">
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
<label>Email address<input type="email" name="email" required></label>
<label>Password<input type="password" name="password" required></label>
<button class="btn full">Sign in</button>
</form><p class="center muted">New student? <a href="register.php">Create an account</a></p></div>
<?php page_end(); ?>
