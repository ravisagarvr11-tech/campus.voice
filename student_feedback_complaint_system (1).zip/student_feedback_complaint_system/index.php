<?php
require_once 'functions.php';
if (!empty($_SESSION['user'])) {
    redirect($_SESSION['user']['role'] === 'admin' ? 'admin.php' : 'student.php');
}
page_start('CampusVoice');
?>
<section class="hero">
  <div>
    <span class="eyebrow">YOUR VOICE MATTERS</span>
    <h1>Make your campus<br><span>better for everyone.</span></h1>
    <p>Share feedback, report concerns and follow the progress of your complaints through one simple platform.</p>
    <div class="actions"><a class="btn" href="register.php">Get started</a><a class="btn secondary" href="login.php">Sign in</a></div>
  </div>
  <div class="hero-card"><div class="bubble">✦</div><h3>Speak up. Be heard.</h3><p>Feedback · Complaints · Resolution</p><div class="fake-stat"><strong>01</strong><span>Submit your concern</span></div><div class="fake-stat"><strong>02</strong><span>Track its progress</span></div><div class="fake-stat"><strong>03</strong><span>See the resolution</span></div></div>
</section>
<?php page_end(); ?>
