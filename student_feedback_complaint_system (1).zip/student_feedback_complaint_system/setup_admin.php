<?php
// Run this file ONCE after importing database.sql, then delete it.
require_once 'functions.php';
$email = 'admin@campusvoice.local';
$password = 'Admin@12345';
$stmt = db()->prepare("SELECT id FROM users WHERE email=?");
$stmt->execute([$email]);
if (!$stmt->fetch()) {
    $stmt = db()->prepare("INSERT INTO users (name,email,student_no,department,password,role) VALUES (?,?,?,?,?,'admin')");
    $stmt->execute(['System Administrator',$email,'ADMIN-001','Administration',password_hash($password,PASSWORD_DEFAULT)]);
    echo "Admin account created.<br>Email: " . e($email) . "<br>Password: " . e($password) . "<br><strong>Delete setup_admin.php now.</strong>";
} else {
    echo "Admin account already exists. Delete setup_admin.php now.";
}
