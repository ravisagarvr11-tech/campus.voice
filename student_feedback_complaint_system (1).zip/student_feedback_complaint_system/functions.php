<?php
require_once __DIR__ . '/config.php';

function e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function redirect(string $path): never {
    header("Location: $path");
    exit;
}
function require_login(): void {
    if (empty($_SESSION['user'])) redirect('login.php');
}
function require_role(string $role): void {
    require_login();
    if ($_SESSION['user']['role'] !== $role) {
        http_response_code(403);
        exit('Access denied.');
    }
}
function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function verify_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $sent = $_POST['csrf'] ?? '';
        if (!hash_equals($_SESSION['csrf'] ?? '', $sent)) {
            http_response_code(419);
            exit('Invalid form token. Go back and try again.');
        }
    }
}
function flash(string $message, string $type = 'success'): void {
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        echo '<div class="alert ' . e($f['type']) . '">' . e($f['message']) . '</div>';
        unset($_SESSION['flash']);
    }
}
function current_user(): array {
    return $_SESSION['user'] ?? [];
}
function page_start(string $title): void {
    $user = current_user();
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' . e($title) . '</title><link rel="stylesheet" href="assets/style.css"></head><body>';
    echo '<header class="topbar"><a class="brand" href="index.php">CampusVoice</a><nav>';
    if ($user) {
        if ($user['role'] === 'admin') echo '<a href="admin.php">Admin Dashboard</a>';
        else echo '<a href="student.php">Dashboard</a>';
        echo '<span class="nav-user">' . e($user['name']) . '</span><a href="logout.php">Logout</a>';
    } else {
        echo '<a href="login.php">Login</a><a href="register.php">Register</a>';
    }
    echo '</nav></header><main class="container">';
    show_flash();
}
function page_end(): void {
    echo '</main><footer>CampusVoice · Student Feedback & Complaint Management</footer><script src="assets/app.js"></script></body></html>';
}
