<?php
require_once 'functions.php'; require_role('admin'); verify_csrf();
$id = (int)($_POST['id'] ?? 0);
$status = $_POST['status'] ?? '';
$reply = trim($_POST['reply'] ?? '');
if ($id < 1 || !in_array($status,['Pending','In Progress','Resolved','Rejected'],true)) {
    flash('Invalid complaint update.','error'); redirect('admin.php');
}
$stmt = db()->prepare("UPDATE complaints SET status=? WHERE id=?");
$stmt->execute([$status,$id]);
if ($reply !== '') {
    $stmt = db()->prepare("INSERT INTO responses (complaint_id,admin_id,reply) VALUES (?,?,?) ON DUPLICATE KEY UPDATE admin_id=VALUES(admin_id),reply=VALUES(reply),updated_at=CURRENT_TIMESTAMP");
    $stmt->execute([$id,current_user()['id'],$reply]);
}
flash('Complaint status and response saved.');
redirect('admin.php');
