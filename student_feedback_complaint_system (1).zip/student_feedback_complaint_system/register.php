<?php
require_once 'functions.php';
if (!empty($_SESSION['user'])) redirect('student.php');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['name'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $student_no = trim($_POST['student_no'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || $student_no === '' || $department === '' || strlen($password) < 8) {
        $error = 'Fill all fields correctly. Password must contain at least 8 characters.';
    } else {
        try {
            $stmt = db()->prepare("INSERT INTO users (name,email,student_no,department,password,role) VALUES (?,?,?,?,?,'student')");
            $stmt->execute([$name,$email,$student_no,$department,password_hash($password, PASSWORD_DEFAULT)]);
            flash('Account created. You can now sign in.');
            redirect('login.php');
        } catch (PDOException $ex) {
            $error = 'Email or student ID is already registered.';
        }
    }
}
page_start('Student Registration');
?>
<div class="form-wrap"><h1>Create student account</h1><p class="muted">Register to submit feedback and track complaints.</p>
<?php if ($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?>
<form method="post" class="panel">
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
<label>Full name<input name="name" required maxlength="100"></label>
<label>Email address<input type="email" name="email" required></label>
<label>Student ID / USN<input name="student_no" required maxlength="40"></label>
<label>Department<input name="department" required placeholder="e.g. Computer Science"></label>
<label>Password<input type="password" name="password" minlength="8" required></label>
<button class="btn full">Create account</button>
</form><p class="center muted">Already registered? <a href="login.php">Sign in</a></p></div>
<?php page_end(); ?>
