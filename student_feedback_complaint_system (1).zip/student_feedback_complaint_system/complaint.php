<?php
require_once 'functions.php'; require_role('student');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $subject = trim($_POST['subject'] ?? '');
    $category = $_POST['category'] ?? '';
    $priority = $_POST['priority'] ?? 'Normal';
    $description = trim($_POST['description'] ?? '');
    $anonymous = isset($_POST['anonymous']) ? 1 : 0;
    $allowed_categories = ['Academics','Infrastructure','Faculty','Hostel','Transport','Canteen','Harassment / Safety','Other'];
    if ($subject === '' || $description === '' || !in_array($category,$allowed_categories,true) || !in_array($priority,['Low','Normal','High'],true)) {
        $error = 'Please complete all fields correctly.';
    } else {
        // The student ID is retained securely so the student can track the case.
        // Admin screens hide the identity when anonymous is selected.
        $stmt = db()->prepare("INSERT INTO complaints (student_id,subject,category,priority,description,is_anonymous) VALUES (?,?,?,?,?,?)");
        $stmt->execute([current_user()['id'],$subject,$category,$priority,$description,$anonymous]);
        $id = db()->lastInsertId();
        flash("Complaint submitted successfully. Your complaint ID is #$id.");
        redirect('my_complaints.php');
    }
}
page_start('Register Complaint');
?>
<div class="form-wrap wide"><h1>Register a complaint</h1><p class="muted">Describe the issue clearly. You can follow its status from your dashboard.</p>
<?php if ($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?>
<form method="post" class="panel">
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
<label>Complaint subject<input name="subject" maxlength="150" required placeholder="Briefly describe the issue"></label>
<div class="two-col"><label>Category<select name="category" required><option value="">Choose category</option><?php foreach (['Academics','Infrastructure','Faculty','Hostel','Transport','Canteen','Harassment / Safety','Other'] as $v): ?><option><?=e($v)?></option><?php endforeach; ?></select></label>
<label>Priority<select name="priority"><option>Normal</option><option>Low</option><option>High</option></select></label></div>
<label>Description<textarea name="description" rows="6" required maxlength="4000" placeholder="Explain what happened, where and when..."></textarea></label>
<label class="check"><input type="checkbox" name="anonymous" value="1"> Submit anonymously (your identity will be hidden from complaint reviewers)</label>
<button class="btn">Submit complaint</button> <a class="btn secondary" href="student.php">Cancel</a>
</form></div><?php page_end(); ?>
