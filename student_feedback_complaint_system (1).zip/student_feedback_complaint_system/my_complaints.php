<?php
require_once 'functions.php'; require_role('student');
$stmt = db()->prepare("SELECT c.*,r.reply FROM complaints c LEFT JOIN responses r ON r.complaint_id=c.id WHERE c.student_id=? ORDER BY c.created_at DESC");
$stmt->execute([current_user()['id']]); $rows = $stmt->fetchAll();
page_start('My Complaints');
?>
<div class="page-heading"><div><h1>My complaints</h1><p class="muted">Track the progress and read responses from the administration.</p></div><a class="btn" href="complaint.php">+ New complaint</a></div>
<section class="panel">
<?php if (!$rows): ?><p class="muted">No complaints submitted yet.</p><?php else: ?>
<div class="table-wrap"><table><thead><tr><th>ID</th><th>Subject</th><th>Category</th><th>Priority</th><th>Submitted</th><th>Status</th><th>Admin response</th></tr></thead><tbody>
<?php foreach ($rows as $c): ?><tr><td>#<?=e($c['id'])?></td><td><?=e($c['subject'])?></td><td><?=e($c['category'])?></td><td><?=e($c['priority'])?></td><td><?=e(date('d M Y',strtotime($c['created_at'])))?></td><td><span class="status <?=strtolower(str_replace(' ','-',$c['status']))?>"><?=e($c['status'])?></span></td><td><?= $c['reply'] ? e($c['reply']) : '<span class="muted">Awaiting response</span>' ?></td></tr><?php endforeach; ?>
</tbody></table></div><?php endif; ?>
</section><?php page_end(); ?>
