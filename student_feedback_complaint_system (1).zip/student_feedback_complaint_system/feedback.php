<?php
require_once 'functions.php'; require_role('student');
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $faculty = trim($_POST['faculty'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $rating = (int)($_POST['rating'] ?? 0);
    $comments = trim($_POST['comments'] ?? '');
    if ($subject === '' || $comments === '' || $rating < 1 || $rating > 5) $error = 'Please complete all required fields and select a rating.';
    else {
        $stmt = db()->prepare("INSERT INTO feedback (student_id,faculty,subject,rating,comments) VALUES (?,?,?,?,?)");
        $stmt->execute([current_user()['id'],$faculty ?: null,$subject,$rating,$comments]);
        flash('Thank you! Your feedback has been submitted.');
        redirect('student.php');
    }
}
page_start('Submit Feedback');
?>
<div class="form-wrap wide"><h1>Share your feedback</h1><p class="muted">Tell us what is working well and what can be improved.</p>
<?php if ($error): ?><div class="alert error"><?=e($error)?></div><?php endif; ?>
<form method="post" class="panel">
<input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
<label>Feedback about<select name="subject" required><option value="">Choose a topic</option><option>Teaching and learning</option><option>Faculty</option><option>Classrooms and laboratories</option><option>Library</option><option>Transport</option><option>Canteen</option><option>Cleanliness and facilities</option><option>Other</option></select></label>
<label>Faculty / Department (optional)<input name="faculty" placeholder="Enter faculty or department"></label>
<label>Rating<select name="rating" required><option value="">Select rating</option><option value="5">5 - Excellent</option><option value="4">4 - Good</option><option value="3">3 - Average</option><option value="2">2 - Poor</option><option value="1">1 - Very poor</option></select></label>
<label>Your comments<textarea name="comments" rows="5" required maxlength="2000" placeholder="Write your feedback..."></textarea></label>
<button class="btn">Submit feedback</button> <a class="btn secondary" href="student.php">Cancel</a>
</form></div><?php page_end(); ?>
