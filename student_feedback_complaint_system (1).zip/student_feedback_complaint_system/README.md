# CampusVoice — Student Feedback & Complaint Management System

A PHP + MySQL mini-project for college students.

## Requirements
- XAMPP (Apache, PHP 8+, MySQL/MariaDB)
- Web browser

## Installation
1. Copy the `student_feedback_complaint_system` folder into `C:\xampp\htdocs\`.
2. Start **Apache** and **MySQL** from XAMPP Control Panel.
3. Open `http://localhost/phpmyadmin`.
4. Import `database.sql` using the Import tab.
5. Open `config.php` and update DB_HOST, DB_NAME, DB_USER and DB_PASS if your MySQL settings differ.
6. Open `http://localhost/student_feedback_complaint_system/setup_admin.php` once to create the admin account.
7. **Delete `setup_admin.php` after the admin account is created.**
8. Open `http://localhost/student_feedback_complaint_system/`.

## Demo admin login
- Email: `admin@campusvoice.local`
- Password: `Admin@12345`
- Change the password before using the project beyond a classroom demo.

## Student flow
1. Register a student account.
2. Sign in.
3. Submit feedback or register a complaint.
4. View complaint status and admin response under My Complaints.

## Admin flow
1. Sign in with the demo admin account.
2. Review all complaints and student feedback.
3. Change a complaint's status and optionally enter a response.
4. Students can see the latest status and response.

## Included features
- Student registration and login
- Password hashing and prepared SQL statements
- CSRF tokens on POST forms
- Student feedback with 1–5 rating
- Complaint categories and priority
- Anonymous complaint option (identity hidden in admin listing; account linkage is retained privately so the student can track the complaint)
- Complaint status tracking
- Admin response to complaints
- Admin dashboard with summary counts
- Responsive CSS layout

## Notes / improvements for final-year quality
- This is an educational starter project, not a production grievance platform.
- Add email notifications, file uploads, complaint escalation, audit logs, pagination and department-wise analytics as future enhancements.
- For real deployment, add HTTPS, stronger admin account provisioning, rate limiting, password reset, access logs, and a formal privacy policy.
